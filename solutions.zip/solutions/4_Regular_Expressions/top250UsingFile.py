import sys
import re

def main():


    pattern = input("Enter movie search string: ")
    # patternx = r"\s*(\w+)\s+.*\1\s+" # word that ends in
    fh_in = open(r"C:\labs\top250_movies.txt", mode="rt")
    for rank, movie in enumerate(fh_in, start=1):
        movie = movie.strip('\n')
        m = re.search(pattern, str(movie), re.IGNORECASE)
        if m:
            print(rf"{rank:>4}: title: {movie}:  match: '{m.group()}'")
    fh_in.close()
    return None


if __name__ == "__main__":
    main()
    sys.exit(0)

