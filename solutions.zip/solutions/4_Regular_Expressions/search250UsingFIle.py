#! /bin/python
# Name:        search.py
# Author:      QA2.0, Donald Cameron
# Revision:    v1.0
# Description: Download the top 250 movies chosen by IMDb users.
"""
    Download and display online movie information.
"""
import sys
import imdb
import re

def main():
    ia = imdb.IMDb()



    pattern_list = [r"^the", r"[0-9]", r".*[aeiou]{3}", r"^(.).*\1$", r"^[^a-zA-Z]+$", r"big", r"\s+(t\w+)\s+.*\1\s+", r"\s+(t\w+)\s+.*?\1\s+"]
    for pattern in pattern_list:
        fh_in = open(r"C:\labs\top250_movies.txt", mode="rt")
        print(f"\n\nSEARCHING MOVIES LIST WITH: '{pattern}'")
        count = 0
        for rank, movie in enumerate(fh_in, start=1):
            movie = movie.strip("\n")
            m = re.search(pattern, str(movie), re.IGNORECASE)
            # m = regexcomp.match(str(movie), re.IGNORECASE)
            if m:
                print(f"{rank:>4}: '{movie}', match: '{m.group()}'")
                count += 1
        print(f"Matched {count} lines")
        fh_in.close()
    return None

if __name__ == "__main__":
    main()
    sys.exit(0)
