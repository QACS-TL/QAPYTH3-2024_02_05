filename = r"C:\labs\top250_movies.txt"  # Always use a raw string for paths.
# Open file handle for WRITING in text mode.
fh_out = open(filename, mode="rt")
movies = list()
# myDict = {'title':'','director':'','year':''}
for rank,row in enumerate(fh_out):
    myDict = {'title': '', 'director': '', 'year': ''}
    myDict["title"] = row
    print(movies)
    movies.append(myDict)
    if len(movies) >= 6:
        break
fh_out.close()
print("final:")
print(movies)