#! /bin/python
# Name:        instances.py
# Author:      QA2.0, Donald Cameron
# Revision:    v1.0
# Description: This is an ultra realistic computer game with Tanks!
"""
    Game of Tanks!
"""

import sys
import tank2


def main():
    """ Main game """
    # Instantiate 3 new Tank objects.
    lancelot_tank = tank2.Tank("German", "Tiger")
    arthur_tank = tank2.Tank("British", "Churchill")
    robin_tank = tank2.Tank("American", "Sherman")

    # . and the game begins.
    lancelot_tank.accel(41)
    lancelot_tank.decel(10)
    arthur_tank.accel(33)

    print(lancelot_tank)



    robin_tank.rotate_left(385)
    robin_tank.accel(15)
    robin_tank.shoot()

    # robin_tank._shells = 99
    robin_tank.speed = -2000
    print(robin_tank.speed)
    robin_tank.speed = 30
    print(robin_tank.speed)

    robin_tank.tank_health = 20

    robin_tank.tank_health = 900
    print(robin_tank.tank_health)

    robin_tank.shoot()
    # ..and success!
    lancelot_tank.take_damage(40)
    arthur_tank.take_damage(62)

    print(lancelot_tank)
    # lancelot_tank.health = 5000

    lancelot_tank.tank_health2 = 55
    print(lancelot_tank.tank_health2)

    lancelot_tank.__add__(robin_tank)

    # lancelot_tank.health = 77
    # print(lancelot_tank.health)

    arthur_tank.tank_health2 = 30000
    print(type(arthur_tank))
    print(arthur_tank.tank_health2)

    lancelot_tank.tank_health = -1
    # And now for some game visuals! Well at least a print statement!
    print(f"Health of Lancelot's Tank = {lancelot_tank.tank_health}")  # Why is this POOR Code?

    return None


if __name__ == "__main__":
    main()
    sys.exit(0)
