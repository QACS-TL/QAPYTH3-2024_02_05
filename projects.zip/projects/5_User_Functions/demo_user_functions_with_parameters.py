#! /bin/python
# Name:        demo_user_functions_with_parameters.py
# Author:      QA2.0, Donald Cameron
# Revision:    v1.0
# Description: This program will demonstrate how to
# define, name, call and pass parameters in and return objects back.
"""
    Displays greeting messages.
"""
import math
import sys


# Example of a user defined function with parameter passing
# and optional defaults
# Placing an asterisk at the start of the parameter list enforces use of parameter names
# def say_hello(*, greeting="ciao", recipient=None):
def say_hello(greeting, recipient):
    """ Display a given greeting to a recipients """

    # Converted parameters to strings for safety!
    # x = greeting + recipient
    # message = str(greeting) + " " + str(recipient)
    message = greeting + " " + recipient
    print(message, end='\n')
    # return None
    greeting += "*"
    greeting = greeting + "*"
    return message

def my_complex_calculator(a, b,c, d, *, e = None, f = None):
    if f is not None:
         x = a * b+ c -d /e + f
    else:
        x = a * b+ c -d /e

def calc_hypotenuse(*, opposite, adjacent):
    return math.sqrt(math.pow(opposite, 2) + math.pow(adjacent, 2))


def main():
    """ Main function - say hello to our friends """

    say_hello("Hello",  "World")  # Positional parameter passing.
    greeting = "Hello"
    recipient = "World"
    say_hello(greeting, recipient)  # Positional parameter passing.
    say_hello(greeting, recipient)  # Positional parameter passing.
    say_hello(recipient="prieteni", greeting="Salutare")  # Named parameter passing.
    say_hello("Namaste", recipient="mere dost")  # Mixed parameter passing.
    # say_hello(greeting= "Namaste", "mere dost")  # Mixed parameter passing.
    # say_hello("Nazdar", 42)  # Try passing in an Integer!
    # say_hello(recipient="mes amis", greeting="Bonjour")  # Mixed in different order.
    res = say_hello("banana", "ice-cream")
    print(res)
    print(say_hello("orange", "More ice-cream"))


    opp = 3
    adj = 4
    hypotenuse = calc_hypotenuse(opposite=opp, adjacent=adj)
    hypotenuse = calc_hypotenuse(opp, adj)
    print(f"hypotenuse = {hypotenuse}")

    # If the function returns an object we can then have the CALLER as
    # a r-value. That means on the RHS of an assignment or embedded within
    # a larger expression.
    # num = say_hello()
    print(f"Default message is {say_hello()}", "")

    return None


if __name__ == "__main__":
    main()
    sys.exit(0)
