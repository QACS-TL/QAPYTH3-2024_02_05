#! /bin/python
# Name:        demo_user_functions_variadic.py
# Author:      QA2.0, Donald Cameron
# Revision:    v1.0
# Description: This program will demonstrate how to
# define, name, call and pass parameters in and return None.
"""
    Displays greeting messages to ALL friends and foes.
"""
import sys

# Example of a Variadic function.
def say_hello(greeting="ciao", *recipients):
    """
    Accept a greeting string and variable number of recipients and
    display message to ALL recipients and returns None.
    """

    # Use an iterator for loop to iterate through objects in tuple.
    for person in recipients:
        if type(person) is str:
            message = greeting + " " + person
            print(message)

    # return None
    return None

def say_hello_dict(**recipients):
    """
    Accept a greeting string and variable number of recipients and
    display message to ALL recipients and returns None.
    """

    for key, value in recipients.items():
        message = str(f"{key} to {value}")

    # Use an iterator for loop to iterate through objects in dictionary.
    message = str(recipients['greeting']) + " " + str(recipients['person1']) + ", " + str(recipients['person3'])
    print(message)

    # Use an iterator for loop to iterate through objects in dictionary.
    message = ""
    for key in recipients:
        message = message + recipients[key] + ", "
    print(message)
    # return None
    return None


def main():
    """ Main function - say hello to our friends """

    # Pass in a variable number of parameters to the function.
    say_hello()
    say_hello('None shall pass', 'green knight', 'arthur', 'patsy')
    say_hello('None shall pass', 'green knight', 45, 67, "lancelot")
    say_hello('None shall pass')
    say_hello_dict(greeting='None shall pass', person1='green knight', person2='arthur', person3='patsy')
    greeting = 'greeting'

    recipients = {greeting:'None shall pass', 'person1':'green knight', 'person2':'patsy'}
    say_hello_dict(recipients)

    return None


if __name__ == "__main__":
    main()
    sys.exit(0)

