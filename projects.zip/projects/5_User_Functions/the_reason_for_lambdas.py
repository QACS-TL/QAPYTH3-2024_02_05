#! /bin/python
# Name:        demo_the_reason_for_lambdas.py
# Author:      QA2.0, Pete Behague
# Revision:    v1.0
# Description: This program will demonstrate how to
# define, name and execute lambdas
"""
    The power of lambda is better shown when you use them as an anonymous function inside another function.

    Say you have a function definition that takes one argument,
    and that argument will be multiplied with an unknown number:
"""
import sys

# Example of a user defined function

# def my_doubler(a):
    #  return a * 2

# def my_tripler(a):
    #  return a * 3


def myfunc(n):
    return lambda a: a * n


def main():
    """ Main function """
    my_doubler = myfunc(2)
    my_tripler = myfunc(3)

    print(my_doubler(11))
    print(my_tripler(11))


if __name__ == "__main__":
    main()
    sys.exit(0)