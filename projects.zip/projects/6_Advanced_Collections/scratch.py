def frange(start, stop, step=0.25):
    if step == 0:
        return []

    curr = float(start)
    while curr < stop:
        yield round(curr, 2)
        curr += step


print(list(frange(1.1, 3)))
print(list(frange(1, 3, 0.33)))
print(list(frange(1, 3, 1)))
print(list(frange(3, 1)))
print(list(frange(1, 3, 0)))
print(list(frange(-1, -0.5, 0.1)))
print(list(frange(-0.5, -1, 0.1)))
print(frange(1, 2))

for num in frange(3.142, 12):
    print(f"{num:05.2f}")
