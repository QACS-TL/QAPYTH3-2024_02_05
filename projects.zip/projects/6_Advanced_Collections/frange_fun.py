def frange(start, stop=None,  step=0.25):
    if step == 0:
        return []
    if stop == None:
        stop = start
        start = 0
    cur = float(start)
    while cur < stop:
        yield round(cur, 2)
        cur += step


#print(list(frange(0, 3.5, 0.25)))
#print(list(frange(3.5)))

if list(frange(0, 3.5, 0.25)) != list(frange(3.5)):
    print("There is an Issue!!!!!")
#
# print("-" * 40)
#
# print(list(frange(1.1, 3)))
# print(list(frange(1, 3, 0.33)))
# print(list(frange(1, 3, 1)))
# print(list(frange(3, 1)))
# print(list(frange(1, 3, 0)))
# print(list(frange(-1, -0.5, 0.1)))
# print(frange(3, 1))
#
# for num in frange(1.342, 12):
#     print(num)