import sys
import imdb
import re


def main():
    ia = imdb.IMDb()
    movies = ia.get_top250_movies()
    while True:
        user_choice = input("Enter name of the film or q/Q to quit: ")
        if user_choice.lower() == 'q':
            break
        else:
            print("Ranking nad name of film(s) matching your choice are: ", end="\n")
            for rank, movie in enumerate(movies, start=1):
                m = re.search(user_choice.upper(), str(movie))
                if m:
                    print(f"{rank:>6d}: {str(movie):<4s}", end="\n")
    print("Display complete")
    """
    for rank, movie in enumerate(movies, start=1):
            print(type(movies))
            print(f"{rank:>6d}: {str(movie):<4s}", end="\n")

    """
    return None


if __name__ == "__main__":
    main()
    sys.exit(0)