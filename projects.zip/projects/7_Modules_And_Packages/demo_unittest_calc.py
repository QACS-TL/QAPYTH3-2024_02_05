#! /bin/python
# Name:        demo_unittest_calc.py
# Author:      QA2.0, Donald Cameron
# Revision:    v1.0
# Description: This program will demonstrate another example of
# creating functions with DocStrings, parameter passing, return values.
"""
    Calculator program with Add, Divide and Multiply functionality.
"""
import unittest
from demo_calculator import add, multiply, divide, increment

class TestCalculator(unittest.TestCase):
    def test_add_positive_numbers(self):
        val = add(4,3)
        self.assertEqual(7, val)

    def test_add_number_and_non_digit(self):
        with self.assertRaises(Exception):
            val = add("$",3)

    def test_add_negative_numbers(self):
        val = add(-4,-3)
        self.assertEqual(-7, val)

    def test_multiply(self):
        self.assertEqual(12, multiply(4, 3))

    def test_divide(self):
        self.assertEqual('5.000', divide(10, 2))

    def test_divide_by_zero(self):
        with self.assertRaises(Exception) as context:
            divide(5, 0)
        self.assertEqual('Divide by zero!', str(context.exception))

    def test_increment(self):
    
        val = increment(4)
        self.assertEqual(5, val)

if __name__ == "__main__":
    unittest.main()

