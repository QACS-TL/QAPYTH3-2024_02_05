
from Finance import banking

bal = 100
bal = banking.withdraw(bal)
bal = banking.deposit(bal)
print(bal)




