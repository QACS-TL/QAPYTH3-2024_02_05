#! /usr/bin/python
# Author: QA2.0 LIVE, V1.0
# Description: This program will 
"""
    Docstring: This program/module will..
"""
# import account
# import banking
#import QATraining
from banking import withdraw
from banking import deposit
#from Finance.banking import deposit
# from Finance.banking import withdraw
