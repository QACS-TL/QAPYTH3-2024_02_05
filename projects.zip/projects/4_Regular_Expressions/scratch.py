import sys
import imdb
import re
searchStr = input("Find which movies?: ")
# searchStr = r"\s*(\w+)\s+.*\1\s+"
reobj = re.compile(searchStr)
def main():
    ia = imdb.IMDb()
    for rank, movie in enumerate(ia.get_top250_movies()):
        if reobj.search(str(movie)):
            print(f"{str(rank):>4s}: {movie}")
    return None

def postcode(postcode):
    import re
    postcode_pattern = r'^[A-Za-z]{1,2}\d{1,2}[A-Za-z]?\s*\d[A-Za-z]{2}$'
    # postcode = 'SW1A 1AA'
    match = re.match(postcode_pattern, postcode)
    if match:
        print("Valid UK postcode")
    else:
        print("Invalid UK postcode")

# main()
postcode('SW1A 1AA')
postcode('SW1A 1AA')