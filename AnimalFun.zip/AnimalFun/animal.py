class Animal:
    def __init__(self, name, colour, limbcount=4):
        self.name = name
        self._limbcount = limbcount
        self.colour = colour

    def eat(self, food):
        # self.__class__.__name__ will return the class of the actual object (i.e. a Dog if method is invoked by a Dog, Animal if invoked by an Animal
        return f"I'm a {self.colour} {self.__class__.__name__} called {self.name} using some of my {self._limbcount} limbs to eat {food}"

    def get_limbcount(self):
        return self._limbcount

    def set_limbcount(self, value):
        if value < 0:
            value = 0
        self._limbcount = value

    limbcount = property(get_limbcount, set_limbcount)




class Vegetable:
    name = "anonymous"
    length = 4
    colour = "Orange"

    def create_vegetable(self, name):
        self.name = name

    def grow(self, increment):
        self.length += increment
